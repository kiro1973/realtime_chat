package com.example.splitapplication.ui.home;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

import com.example.splitapplication.R;
import com.example.splitapplication.ui.home.modules.clanAdapter;
import com.example.splitapplication.ui.home.modules.clanGetSet;


@SuppressLint("Registered")
public class bottomFragClan extends  Fragment implements clanAdapter.OnItemClickListener {

    public String TAG="bottomFragClan: ";

    private RecyclerView mRecyclerView;
    private clanAdapter mAdapter;

    private ProgressBar mProgressCircle;

    private List<clanGetSet> mClanGetSet;

    ImageView no_friend_image;
    TextView no_friend_text;

    SwipeRefreshLayout mSwipeRefreshLayout;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container,  Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.bottom_frag_myclan, container, false);

        SharedPreferences User_getSharedPrefrence = getActivity().getSharedPreferences("Setting", MODE_PRIVATE);
        final String user_child= User_getSharedPrefrence.getString("Always_User_Child","!!!!");

        mRecyclerView = view.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayout = new LinearLayoutManager(getActivity());
        linearLayout.setReverseLayout(false);
        linearLayout.setSmoothScrollbarEnabled(true);
        mRecyclerView.setLayoutManager(linearLayout);

        mSwipeRefreshLayout=view.findViewById(R.id.swipeRefresh);
        no_friend_image=view.findViewById(R.id.no_friend_image);
        no_friend_text = view.findViewById(R.id.no_friend_text);

        no_friend_text.setVisibility(view.GONE);
        no_friend_image.setVisibility(view.GONE);

        mProgressCircle = view.findViewById(R.id.progress_circle);

        mClanGetSet = new ArrayList<>();

        mAdapter = new clanAdapter(mActivity, mClanGetSet);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(bottomFragClan.this);
        mClanGetSet.clear();
        //add user 1
        clanGetSet clanGetSet = new clanGetSet();
        clanGetSet.setKey("1234");
        clanGetSet.setn("User Name 1");
        clanGetSet.setm("https://a.storyblok.com/f/191576/1200x800/215e59568f/round_profil_picture_after_.webp");
        Log.d(TAG, "clanGetSet.getn: " +clanGetSet.getn()+ " \n");
        Log.d(TAG, "clanGetSet.getm: " +clanGetSet.getm()+ " \n");
        Log.d(TAG, "clanGetSet.getKey: " +clanGetSet.getKey()+ " \n");
        clanGetSet.setKey(clanGetSet.getKey());
        mClanGetSet.add(clanGetSet);
        //add user 2
        clanGetSet clanGetSet1 = new clanGetSet();
        clanGetSet1.setKey("4321");
        clanGetSet1.setn("User Name 2");
        clanGetSet1.setm("https://t4.ftcdn.net/jpg/03/64/21/11/360_F_364211147_1qgLVxv1Tcq0Ohz3FawUfrtONzz8nq3e.jpg");
        Log.d(TAG, "clanGetSet.getn: " +clanGetSet1.getn()+ " \n");
        Log.d(TAG, "clanGetSet.getm: " +clanGetSet1.getm()+ " \n");
        Log.d(TAG, "clanGetSet.getKey: " +clanGetSet1.getKey()+ " \n");
        clanGetSet1.setKey(clanGetSet1.getKey());

        mClanGetSet.add(clanGetSet1);
        no_friend_image.setVisibility(View.INVISIBLE);
        no_friend_text.setVisibility(View.INVISIBLE);

        if(mAdapter.getItemCount()==0) {
            mProgressCircle.setVisibility(View.INVISIBLE);
            mSwipeRefreshLayout.setRefreshing(false);
            no_friend_image.setVisibility(View.VISIBLE);
            no_friend_text.setVisibility(View.VISIBLE);
        }

        mAdapter.notifyDataSetChanged();
        mProgressCircle.setVisibility(View.INVISIBLE);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Refresh items
                refreshItems();
            }
        });
        return view;
    }

    void refreshItems() {
        onItemsLoadComplete();
    }

    void onItemsLoadComplete() {
        mSwipeRefreshLayout.setRefreshing(false);
    }

    private Activity mActivity;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivity = getActivity();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mActivity = null;
    }

    private void doAction() {
        if (mActivity == null) {
            return;
        }
    }

    public void onItemClick(int position) {
        Log.v(TAG, "Normal click at position:"  + position);
    }

    public void onGetReport(int position) {
        clanGetSet selectedItem = mClanGetSet.get(position);

    }
    public void onGetDeleteClick(int position) {
        final clanGetSet selectedItem = mClanGetSet.get(position);
    }

}

