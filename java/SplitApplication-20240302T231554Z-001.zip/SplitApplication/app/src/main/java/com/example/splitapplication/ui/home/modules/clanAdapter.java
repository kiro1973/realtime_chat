package com.example.splitapplication.ui.home.modules;


import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.splitapplication.R;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;


public class clanAdapter extends RecyclerView.Adapter<clanAdapter.ImageViewHolder> {
	private Context mContext;
	private List<clanGetSet> mclans;
	private OnItemClickListener mListener;
	private ProgressDialog pDialog;
	private String TAG = " clanAdapter: ";

	public clanAdapter(Context context, List<clanGetSet> clanGetSets) {
		mContext = context;
		mclans = clanGetSets;
	}

	@Override
	public ImageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
		View v = LayoutInflater.from(mContext).inflate(R.layout.clan_item, parent, false);
		return new ImageViewHolder(v);
	}

	@Override
	public void onBindViewHolder(ImageViewHolder holder, @SuppressLint("RecyclerView") final int position) {
		final clanGetSet clanGetSetCurrent = mclans.get(position);

		SharedPreferences User_getSharedPrefrence = mContext.getSharedPreferences("Setting", MODE_PRIVATE);
		holder.userProfileName.setText(clanGetSetCurrent.getn());

		if(mContext!=null) {
			Glide
					.with(mContext)
					.load(clanGetSetCurrent.getm())
					.thumbnail(0.01f)
					.apply(RequestOptions.circleCropTransform())
					.into(holder.userProfileImage);
		}
		holder.itemView.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick (View view){
					next(clanGetSetCurrent.getn(),clanGetSetCurrent.getm(),position);
				}
		});
		holder.userProfileLastChatTime.setText("5minute ago");
		holder.userProfileLastChat.setText("Hello how are you?");
	}
	@Override
	public int getItemCount() {
		return mclans.size();
	}


	public class ImageViewHolder  extends RecyclerView.ViewHolder implements View.OnClickListener,
			View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener  {
		public TextView userProfileName,userProfileLastChat,userProfileLastChatTime;
		public ImageView userProfileImage;

		public ImageViewHolder(View itemView) {
			super(itemView);


			userProfileImage = itemView.findViewById(R.id.userProfileImage);
			userProfileName = itemView.findViewById(R.id.userProfileName);
			userProfileLastChat = itemView.findViewById(R.id.userProfileLastChat);
			userProfileLastChatTime = itemView.findViewById(R.id.userProfileLastChatTime);


			itemView.setOnClickListener(this);
			itemView.setOnCreateContextMenuListener(this);
		}

		@Override
		public void onClick(View v) {
			if (mListener != null) {
				int position = getAdapterPosition();
				if (position != RecyclerView.NO_POSITION) {
					mListener.onItemClick(position);
				}
			}
		}

		@Override
		public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
			menu.setHeaderTitle("Select Action");
			MenuItem Report = menu.add(Menu.NONE, 1, 1, "Report");
			MenuItem delete = menu.add(Menu.NONE, 2, 2, "Remove");

			Report.setOnMenuItemClickListener(this);
			delete.setOnMenuItemClickListener(this);
		}

		@Override
		public boolean onMenuItemClick(MenuItem item) {
			if (mListener != null) {
				int position = getAdapterPosition();
				if (position != RecyclerView.NO_POSITION) {

					switch (item.getItemId()) {
						case 1:
							mListener.onGetReport(position);
							return true;
						case 2:
							mListener.onGetDeleteClick(position);
							return true;
					}
				}
			}
			return false;
		}

	}






	public interface OnItemClickListener {
		void onItemClick(int position);

		void onGetReport(int position);

		void onGetDeleteClick(int position);
	}

	public void setOnItemClickListener(OnItemClickListener listener) {
		mListener = listener;
	}



	public void next(String final_me,String new_Image_uri,int position){
		final clanGetSet clanGetSetCurrent = mclans.get(position);
		Intent intent =new Intent(mContext, chatroom.class);
		intent.putExtra("user_nick", final_me);
		intent.putExtra("user_name", clanGetSetCurrent.getKey());
		intent.putExtra("imaged", new_Image_uri);
		mContext.startActivity(intent);
	}
}


