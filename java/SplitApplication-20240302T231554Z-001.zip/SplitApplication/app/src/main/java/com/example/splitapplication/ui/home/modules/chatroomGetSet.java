package com.example.splitapplication.ui.home.modules;

import androidx.annotation.Keep;

@Keep
public class chatroomGetSet {
    public String m,mKey,i;

    public chatroomGetSet(String m)
    {
        this.m=m;
    }
    public chatroomGetSet(){
    }

    public String getm() { return m; }

    public void setm(String m) { this.m = m; }
    public String geti() { return i; }

    public void seti(String i) { this.i = i; }

    public String getKey() {
        return mKey;
    }

    public void setKey(String key) {
        mKey = key;
    }
}




////////////////////////////////////////////////////////////////////////////////////////////////////
/*
done

 */
