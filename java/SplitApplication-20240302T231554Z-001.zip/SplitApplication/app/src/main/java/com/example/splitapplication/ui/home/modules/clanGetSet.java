package com.example.splitapplication.ui.home.modules;

import androidx.annotation.Keep;

@Keep
public class clanGetSet {

    public String mn;
    public String mm;
    public String mKey;

    public clanGetSet() {
    }
    public clanGetSet(String n, String m) {

        mn = n;
        mm = m;
    }

    public String getn() {
        return mn;
    }

    public void setn(String n) {
        mn = n;
    }

    public String getm() {
        return mm;
    }

    public void setm(String m) {
        mm = m;
    }

    public String getKey() {
        return mKey;
    }

    public void setKey(String key) {
        mKey = key;
    }
}



////////////////////////////////////////////////////////////////////////////////////////////////////
/*

done
 */
