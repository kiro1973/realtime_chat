package com.example.splitapplication.ui.home.modules;


import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.splitapplication.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;


public class chatroom extends AppCompatActivity  implements TextToSpeech.OnInitListener{


    String myMsg="!";
    EditText ChatMsg;
    Button ChatBtn,Backing ;
    String comb="!";
    TextView me,you,clock;

    String Hey;

    String TAG="chatroom: ";

    TextToSpeech textToSpeech;

    private ProgressBar mProgressCircle;
    private RecyclerView mRecyclerView;
    private chatroomAdapter mAdapter;
    private List<chatroomGetSet> mchat;
    private static final int Total_load_chat =10;
    public int Current_page=1;

    ImageView img_y;
    private int item_no=0;
    private String send_Ready="true";
    String selected_User_imaged="!";
    String selected_User_child="!";
    SwipeRefreshLayout mSwipeRefreshLayout;
    String selected_User_nick;
    Intent intent;

    private TextView speakButton;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.chat_room);

        SharedPreferences sp = getApplicationContext().getSharedPreferences("Setting", MODE_PRIVATE);

        //set rotation settings
        if( sp.getBoolean("rotate", false)) {
            this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        intent = getIntent();
        selected_User_child = intent.getStringExtra("user_name");
        selected_User_nick = intent.getStringExtra("user_nick");
        selected_User_imaged= intent.getStringExtra("imaged");
        img_y=findViewById(R.id.userProfileImage);

        LinearLayout menu = (LinearLayout) findViewById(R.id.menu_layout);
        Backing=findViewById(R.id.backing);
        Backing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        speakButton =  findViewById(R.id.button_voice);
        speakButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                askSpeechInput();
            }
        });

        textToSpeech= new TextToSpeech(getApplicationContext(), this, "com.google.android.tts");
        you=findViewById(R.id.chatUserName);
        Glide
                .with(getApplicationContext())
                .load(selected_User_imaged)
                .thumbnail(0.1f)
                .apply(RequestOptions.circleCropTransform())
                .into(img_y);

        mSwipeRefreshLayout=findViewById(R.id.swipe_RefreshLayout);

        mRecyclerView = findViewById(R.id.chat_recycle);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayout = new LinearLayoutManager(getApplicationContext());
        linearLayout.setReverseLayout(false);
        linearLayout.setStackFromEnd(true);
        linearLayout.setSmoothScrollbarEnabled(true);
        mRecyclerView.setLayoutManager(linearLayout);

        mProgressCircle = findViewById(R.id.chat_circle);

        ChatBtn=findViewById(R.id.chat_send);
        ChatMsg=findViewById(R.id.chat_str);
        clock=findViewById(R.id.clock);

        ChatMsg.setVisibility(View.VISIBLE);
        clock.setVisibility(View.INVISIBLE);

        mchat= new ArrayList<>();
        mAdapter = new chatroomAdapter(chatroom.this, mchat,selected_User_imaged);
        mRecyclerView.setAdapter(mAdapter);

        ChatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myMsg = String.valueOf(ChatMsg.getText());
                if(send_Ready.equals("true")){
                    if(!ChatMsg.getText().toString().trim().equals("")){
                        long timer = (long) (TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));

                        senders(myMsg);
                        send_Ready="false";
                        new CountDownTimer(4000, 1000) {

                            @SuppressLint("SetTextI18n")
                            public void onTick(long millisUntilFinished) {
                                clock.setVisibility(View.VISIBLE);
                                ChatBtn.setVisibility(View.INVISIBLE);
                                clock.setText(""+ millisUntilFinished / 1000);
                            }

                            public void onFinish() {
                                send_Ready="true";
                                clock.setVisibility(View.INVISIBLE);
                                ChatBtn.setVisibility(View.VISIBLE);
                            }

                        }.start();

                    }else{
                        Toast.makeText(getApplicationContext(), "Please Write your Message!", Toast.LENGTH_SHORT).show();}
                }else{

                    Toast.makeText(getApplicationContext(), "Please Wait for 5 seconds!", Toast.LENGTH_SHORT).show();
                }

            }
        });

        read();

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Refresh items

                item_no = 0;
                Current_page++;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                readMore();
                                mSwipeRefreshLayout.setRefreshing(false);
                                mProgressCircle.setVisibility(View.INVISIBLE);
                            }
                        }, 1000);
                    }
                });
            }
        });
        speakOut(Hey);

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(chatroom.this, menu);
                popupMenu.getMenuInflater().inflate(R.menu.chat_menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        if(menuItem.getItemId()==R.id.remove) {
                            SharedPreferences User_getSharedPrefrence = getApplicationContext().getSharedPreferences("Setting", MODE_PRIVATE);
                            String user_child=  User_getSharedPrefrence.getString("Always_User_Child","!!!!");
                            //delete user
                            finish();
                        }else {
                            //Send Mail
                        }
                        return true;
                    }
                });
                popupMenu.show();
            }
        });

    }


//////////////////////////////////////Send_message///////////////////////////////////////////////////

    public void readMore(){

        if(mchat.size() == 0) {
            mProgressCircle.setVisibility(View.INVISIBLE);

            mSwipeRefreshLayout.setRefreshing(false);
        }
        chatroomGetSet chatroomGetSet = new chatroomGetSet();
        chatroomGetSet.setKey("4321");
        chatroomGetSet.setm("Thanks you for adding me as friend.");
        chatroomGetSet.seti("https://a.storyblok.com/f/191576/1200x800/215e59568f/round_profil_picture_after_.webp");
        mchat.add(item_no++, chatroomGetSet);
        mAdapter.notifyDataSetChanged();
        mRecyclerView.scrollBy(5,0);

    }

    public void senders(String chat ){
        ChatMsg.getText().clear();

        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    //////////////////////////////////////read_message///////////////////////////////////////////////////
    public void read(){
        if(mchat.size() == 0) {
            mProgressCircle.setVisibility(View.INVISIBLE);

            mSwipeRefreshLayout.setRefreshing(false);
        }
        SharedPreferences sp = getApplicationContext().getSharedPreferences("Setting", MODE_PRIVATE);
        final SharedPreferences.Editor editor = sp.edit();

        //Add Chat 1
        chatroomGetSet chatroomGetSet = new chatroomGetSet();
        chatroomGetSet.setKey("1234");
        chatroomGetSet.setm("Hello how are you?");;
        chatroomGetSet.seti("https://t4.ftcdn.net/jpg/03/64/21/11/360_F_364211147_1qgLVxv1Tcq0Ohz3FawUfrtONzz8nq3e.jpg");
        item_no++;
        mchat.add(chatroomGetSet);
        mAdapter.notifyDataSetChanged();
        //Add Chat 2
        chatroomGetSet chatroomGetSet1 = new chatroomGetSet();
        chatroomGetSet1.setKey("4321");
        chatroomGetSet1.setm("I am fine. That's All About me. Thanks");
        chatroomGetSet1.seti("https://a.storyblok.com/f/191576/1200x800/215e59568f/round_profil_picture_after_.webp");
        item_no++;
        mchat.add(chatroomGetSet1);
        mAdapter.notifyDataSetChanged();
        mRecyclerView.scrollToPosition(mchat.size() - 1);
        mSwipeRefreshLayout.setRefreshing(false);
        mProgressCircle.setVisibility(View.INVISIBLE);
    }

    private void askSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                "Hi! Say Your Message");
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(getApplicationContext(),
                    "Speech Not Supported",
                    Toast.LENGTH_SHORT).show();
            Log.i(TAG, "Speech Not Supported: "+e );
        }
    }

    // Receiving speech input
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    ChatMsg.setText(result.get(0));
                }
                break;
            }

        }
    }

    @Override
    public void onDestroy() {

        textToSpeech.shutdown();

        super.onDestroy();
    }

    @Override
    public void onInit(int status) {

        SharedPreferences sp = getApplicationContext().getSharedPreferences("Setting", MODE_PRIVATE);

        SharedPreferences User_getSharedPrefrence = getApplicationContext().getSharedPreferences("Setting", MODE_PRIVATE);
        String user_child=  User_getSharedPrefrence.getString("Always_User_Child","!!!!");

        if (sp.getBoolean(user_child+"speak", true) == true) {

            if (status == TextToSpeech.SUCCESS) {
                Set<String> a = new HashSet<>();

                String locale = getApplicationContext().getResources().getConfiguration().locale.getCountry();

                String Voices;
                if(selected_User_nick==null||selected_User_nick.equals("")){ selected_User_nick=" ";}
                if (selected_User_nick.trim().length()>=1&&(selected_User_nick.trim().substring(0, 1).equals("M"))) {
                    a.add("male");
                    Voices = "en-us-x-sfg#male_2-local";
                } else {
                    a.add("female");
                    Voices = "en-us-x-sfg#female_2-local";
                }



                Voice v = new Voice(Voices.trim(), new Locale(Locale.getDefault().getLanguage(), locale), 4000, 200, true, a);

                textToSpeech.setVoice(v);
                textToSpeech.setSpeechRate(0.9f);

                int result = textToSpeech.setVoice(v);

                if (result == TextToSpeech.LANG_MISSING_DATA
                        || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.i(TAG, "This Language Changed" );
                    result = textToSpeech.setLanguage(Locale.US);
                }

                if (result == TextToSpeech.LANG_MISSING_DATA
                        || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.w(TAG, "This Language is not supported" );
                } else {
                    speakOut(Hey);
                }

            } else {
                Log.e(TAG, "This Language initialization failed!" );
            }
        }
    }

    private void speakOut(String message) {

        textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null);
    }

}
